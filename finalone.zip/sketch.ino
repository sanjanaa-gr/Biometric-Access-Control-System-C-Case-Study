// ===================================================================
//  APARTMENT SMART LOCK v2
//  SD logging + resident alert panel + AI risk engine
//  Board: Arduino MEGA 2560 (Wokwi)
//
//  NEW IN v2
//   1. PINs are stored as salted hashes (not plain text) on the SD card
//   2. Non-blocking door + siren (tamper / keypad keep working)
//   3. Duress PIN: your PIN with the LAST DIGIT +1 opens the door and
//      sends a SILENT alarm to every other flat
//   4. One-time guest PIN (admin generates, valid 5 min, single use)
//   5. Escalating lockout: 30s -> 60s -> 120s -> 240s
//   6. AI typing profiles saved to SD (PROFILES.TXT) - survive reboot
//   7. Failed PIN guesses are no longer written to the log
//   8. Admin menu has 2 pages (guest PIN, list users, clear logs)
//   9. Auto-clear of half-typed PIN after 10 s, key-press beep
//  10. Extra serial commands (s = status, c = clear logs, h = help)
//  11. Lock fails secure: door is forced shut when an alert fires
// ===================================================================
#include <SPI.h>
#include <SD.h>
#include <Keypad.h>
#include <LiquidCrystal_I2C.h>
#include <Servo.h>

// ---------- Keypad (4x4) ----------
const byte ROWS = 4, COLS = 4;
char keys[ROWS][COLS] = {
  {'1','2','3','A'},
  {'4','5','6','B'},
  {'7','8','9','C'},
  {'*','0','#','D'}
};
byte rowPins[ROWS] = {9, 8, 7, 6};
byte colPins[COLS] = {5, 4, 3, 2};
Keypad keypad = Keypad(makeKeymap(keys), rowPins, colPins, ROWS, COLS);

// ---------- Displays ----------
LiquidCrystal_I2C lcd(0x27, 16, 2);     // on the lock: shows what is typed
LiquidCrystal_I2C panel(0x26, 20, 4);   // external resident notice board

// ---------- Hardware pins ----------
Servo doorLock;
const int SERVO_PIN      = 10;
const int LOCK_ANGLE     = 0;
const int UNLOCK_ANGLE   = 90;
const int BUZZER_PIN     = 11;
const int LED_PIN        = 12;   // green: door open
const int ALERT_LED_PIN  = 24;   // red: security alert
const int FP_MATCH_PIN   = 13;   // simulated fingerprint: match
const int FP_NOMATCH_PIN = A0;   // simulated fingerprint: no match
const int TAMPER_PIN     = 22;   // simulated force / vibration sensor
const int SD_CS          = 53;

// ---------- Settings ----------
#define MAX_USERS        8
#define PIN_LENGTH       4
#define FLAT_LENGTH      3
#define MAX_ATTEMPTS     3
#define LOCKOUT_MS       30000UL
#define MAX_LOCK_LEVEL   3            // lockout doubles up to 30s * 2^3
#define TAMPER_COOLDOWN  10000UL
#define ENTRY_TIMEOUT_MS 15000UL
#define IDLE_CLEAR_MS    10000UL      // clear half-typed PIN
#define DOOR_OPEN_MS     3000UL
#define GUEST_VALID_MS   300000UL     // guest PIN lives 5 minutes
#define SIREN_MS         4800UL
const bool SHOW_ENTERED_DIGITS = false;   // true = show digits instead of '*'

const char* USERS_FILE   = "USERS.TXT";    // SD library needs 8.3 file names
const char* ACCESS_FILE  = "ACCESS.LOG";
const char* ALERT_FILE   = "ALERTS.LOG";
const char* PROFILE_FILE = "PROFILES.TXT";
const char* PIN_SALT     = "AptLock#26";
const String SUPER_ADMIN_PIN = "9999";

// ---------- Resident database (loaded from SD) ----------
String userFlat[MAX_USERS];
String userName[MAX_USERS];
String userPin[MAX_USERS];                // stores the HASH of the PIN
int totalUsers = 0;

// ---------- State ----------
bool sdReady = false;
String enteredPIN = "";
int failedAttempts = 0;
int lockoutLevel = 0;
unsigned long lockedUntil = 0;
unsigned long lastTamper = 0;
unsigned long lastCountdown = 0;
unsigned long screenResetAt = 0;          // when to return to the idle screen
int alertCount = 0;
int grantedCount = 0;
int deniedCount = 0;
String lastEvent = "None";

// Door (non-blocking)
bool doorIsOpen = false;
unsigned long doorOpenUntil = 0;

// Siren (non-blocking)
unsigned long sirenEnd = 0;
unsigned long sirenLast = 0;
bool sirenPhase = false;

// Guest PIN (RAM only, single use)
String guestPin = "";
String guestFlat = "";
unsigned long guestExpires = 0;

// Fingerprint edge detection
bool fpMatchWas = false;
bool fpNoMatchWas = false;

// ===================================================================
//  MACHINE LEARNING: keystroke dynamics + neural-network risk scorer
// ===================================================================
#define RISK_THRESHOLD 0.70
float userMeanGap[MAX_USERS];            // learned average ms between key presses
float userStdGap[MAX_USERS];             // learned variation of that rhythm
int   userSamples[MAX_USERS];            // how many times the lock has learned this user
unsigned long lastKeyTime = 0;
unsigned long gapSum = 0;
int gapCount = 0;

// Neural network 3 inputs -> 4 hidden neurons (ReLU) -> 1 output (sigmoid)
// NN_ prefix: Arduino already defines B1, B2... as binary constants.
const float NN_W1[4][3] = {
  {2.5, 1.2, 1.5},
  {1.8, 2.0, 0.5},
  {-0.5, 2.2, 2.0},
  {3.0, 0.3, 1.0}
};
const float NN_B1[4] = {-1.0, -1.0, -1.0, -1.5};
const float NN_W2[4] = {1.5, 1.2, 1.4, 1.6};
const float NN_B2    = -2.0;

float relu(float x)    { return x > 0 ? x : 0; }
float sigmoid(float x) { return 1.0 / (1.0 + exp(-x)); }

float neuralRisk(float x0, float x1, float x2) {
  float in[3] = {x0, x1, x2};
  float out = NN_B2;
  for (int h = 0; h < 4; h++) {
    float s = NN_B1[h];
    for (int i = 0; i < 3; i++) s += NN_W1[h][i] * in[i];
    out += NN_W2[h] * relu(s);
  }
  return sigmoid(out);
}

void resetTyping() {
  gapSum = 0;
  gapCount = 0;
  lastKeyTime = 0;
}

float riskScore(int idx) {
  float avgGap = gapCount ? (float)gapSum / gapCount : 0;

  // Feature 1: typing rhythm deviation (only after the lock has learned the user)
  float x0 = 0;
  if (userSamples[idx] >= 3) {
    float z = fabs(avgGap - userMeanGap[idx]) / max(userStdGap[idx], 50.0f);
    x0 = min(z, 4.0f) / 4.0f;
  }
  // Feature 2: recent failed attempts
  float x1 = (float)failedAttempts / MAX_ATTEMPTS;
  // Feature 3: tampering in the last 60 seconds
  float x2 = (lastTamper != 0 && millis() - lastTamper < 60000UL) ? 1.0 : 0.0;

  return neuralRisk(x0, x1, x2);
}

// ===================================================================
//  Utility
// ===================================================================
String timestamp() {                      // uptime clock (add an RTC for real time)
  unsigned long s = millis() / 1000;
  char buf[16];
  sprintf(buf, "T+%02lu:%02lu:%02lu", s / 3600, (s / 60) % 60, s % 60);
  return String(buf);
}

String pad20(String s) {
  if (s.length() > 20) s = s.substring(0, 20);
  while (s.length() < 20) s += ' ';
  return s;
}

void logEvent(const char* file, const String& text) {
  String line = timestamp() + "," + text;
  Serial.println("[LOG " + String(file) + "] " + line);
  if (!sdReady) return;
  File f = SD.open(file, FILE_WRITE);
  if (f) { f.println(line); f.close(); }
  else   { Serial.println("SD write failed!"); }
}

void printFile(const char* name) {
  if (!sdReady) { Serial.println("SD not ready"); return; }
  File f = SD.open(name);
  if (!f) { Serial.println("No file: " + String(name)); return; }
  Serial.println("----- " + String(name) + " -----");
  while (f.available()) Serial.write(f.read());
  f.close();
  Serial.println("----- end -----");
}

// Salted FNV-1a hash -> 8 hex characters
String hashPin(const String& pin) {
  String s = String(PIN_SALT) + pin;
  unsigned long h = 2166136261UL;
  for (unsigned int i = 0; i < s.length(); i++) {
    h ^= (unsigned char)s[i];
    h *= 16777619UL;
  }
  char buf[9];
  sprintf(buf, "%08lX", h);
  return String(buf);
}

// Change the last digit of a PIN by +1 (duress) or -1 (undo duress)
String shiftLast(const String& pin, int delta) {
  if (pin.length() == 0) return pin;
  String s = pin;
  int d = (s[s.length() - 1] - '0' + delta + 10) % 10;
  s.setCharAt(s.length() - 1, (char)('0' + d));
  return s;
}

// ===================================================================
//  Background tasks: door re-lock + siren (never block the loop)
// ===================================================================
void openDoor() {
  doorLock.write(UNLOCK_ANGLE);
  digitalWrite(LED_PIN, HIGH);
  doorIsOpen = true;
  doorOpenUntil = millis() + DOOR_OPEN_MS;
}

void lockDoorNow() {
  doorLock.write(LOCK_ANGLE);
  digitalWrite(LED_PIN, LOW);
  doorIsOpen = false;
}

void startSiren() {
  sirenEnd = millis() + SIREN_MS;
  sirenLast = 0;
  sirenPhase = false;
}

bool sirenActive() { return sirenEnd != 0; }

void backgroundTasks() {
  if (doorIsOpen && millis() >= doorOpenUntil) lockDoorNow();

  if (sirenEnd != 0) {
    if (millis() >= sirenEnd) {
      noTone(BUZZER_PIN);
      digitalWrite(ALERT_LED_PIN, LOW);
      sirenEnd = 0;
    } else if (millis() - sirenLast >= 200) {
      sirenLast = millis();
      sirenPhase = !sirenPhase;
      tone(BUZZER_PIN, sirenPhase ? 1800 : 900);
      digitalWrite(ALERT_LED_PIN, sirenPhase ? HIGH : LOW);
    }
  }
}

// Wait without freezing door / siren
void waitMs(unsigned long ms) {
  unsigned long start = millis();
  while (millis() - start < ms) backgroundTasks();
}

// ===================================================================
//  User database on SD card   (line format:  flat,name,pinHash)
// ===================================================================
void saveUsers() {
  if (!sdReady) return;
  SD.remove(USERS_FILE);
  File f = SD.open(USERS_FILE, FILE_WRITE);
  if (!f) { Serial.println("Cannot write USERS.TXT"); return; }
  for (int i = 0; i < totalUsers; i++) {
    f.println(userFlat[i] + "," + userName[i] + "," + userPin[i]);
  }
  f.close();
}

void saveProfiles() {
  if (!sdReady) return;
  SD.remove(PROFILE_FILE);
  File f = SD.open(PROFILE_FILE, FILE_WRITE);
  if (!f) { Serial.println("Cannot write PROFILES.TXT"); return; }
  for (int i = 0; i < totalUsers; i++) {
    f.println(userFlat[i] + "," + String(userMeanGap[i], 1) + "," +
              String(userStdGap[i], 1) + "," + String(userSamples[i]));
  }
  f.close();
}

void loadDefaultUsers() {
  userFlat[0] = "101"; userName[0] = "Ravi";   userPin[0] = hashPin("1234");
  userFlat[1] = "102"; userName[1] = "Meena";  userPin[1] = hashPin("2345");
  userFlat[2] = "103"; userName[2] = "Arjun";  userPin[2] = hashPin("3456");
  userFlat[3] = "104"; userName[3] = "Priya";  userPin[3] = hashPin("4567");
  totalUsers = 4;
}

void loadUsers() {
  totalUsers = 0;
  if (!sdReady) { loadDefaultUsers(); return; }

  if (!SD.exists(USERS_FILE)) {           // first boot: create the file
    loadDefaultUsers();
    saveUsers();
    return;
  }
  File f = SD.open(USERS_FILE);
  if (!f) { loadDefaultUsers(); return; }

  bool migrated = false;
  while (f.available() && totalUsers < MAX_USERS) {
    String line = f.readStringUntil('\n');
    line.trim();
    if (line.length() == 0) continue;
    int c1 = line.indexOf(',');
    int c2 = line.indexOf(',', c1 + 1);
    if (c1 < 0 || c2 < 0) continue;
    String p = line.substring(c2 + 1);
    if (p.length() == PIN_LENGTH) {       // old plain-text PIN -> convert to hash
      p = hashPin(p);
      migrated = true;
    }
    userFlat[totalUsers] = line.substring(0, c1);
    userName[totalUsers] = line.substring(c1 + 1, c2);
    userPin[totalUsers]  = p;
    totalUsers++;
  }
  f.close();
  if (totalUsers == 0) { loadDefaultUsers(); saveUsers(); }
  else if (migrated)   { saveUsers(); }
}

int findByPin(const String& pin) {
  String h = hashPin(pin);
  for (int i = 0; i < totalUsers; i++) if (userPin[i] == h) return i;
  return -1;
}
int findByFlat(const String& flat) {
  for (int i = 0; i < totalUsers; i++) if (userFlat[i] == flat) return i;
  return -1;
}

void loadProfiles() {
  if (!sdReady || !SD.exists(PROFILE_FILE)) return;
  File f = SD.open(PROFILE_FILE);
  if (!f) return;
  while (f.available()) {
    String line = f.readStringUntil('\n');
    line.trim();
    int c1 = line.indexOf(',');
    int c2 = line.indexOf(',', c1 + 1);
    int c3 = line.indexOf(',', c2 + 1);
    if (c1 < 0 || c2 < 0 || c3 < 0) continue;
    int idx = findByFlat(line.substring(0, c1));
    if (idx < 0) continue;
    userMeanGap[idx] = line.substring(c1 + 1, c2).toFloat();
    userStdGap[idx]  = line.substring(c2 + 1, c3).toFloat();
    userSamples[idx] = line.substring(c3 + 1).toInt();
  }
  f.close();
}

// A PIN is "taken" if it (or its duress / un-duress twin) belongs to someone else
bool pinTaken(const String& pin, int exceptIdx) {
  int a = findByPin(pin);
  int b = findByPin(shiftLast(pin, +1));
  int c = findByPin(shiftLast(pin, -1));
  if (a >= 0 && a != exceptIdx) return true;
  if (b >= 0 && b != exceptIdx) return true;
  if (c >= 0 && c != exceptIdx) return true;
  if (guestPin.length() && (pin == guestPin || shiftLast(pin, +1) == guestPin)) return true;
  return false;
}

bool addUser(const String& flat, const String& pin) {
  if (totalUsers >= MAX_USERS) { Serial.println("Add failed: user list full"); return false; }
  if (findByFlat(flat) >= 0)   { Serial.println("Add failed: flat exists"); return false; }
  if (pinTaken(pin, -1))       { Serial.println("Add failed: PIN not allowed"); return false; }
  userFlat[totalUsers] = flat;
  userName[totalUsers] = "Resident";
  userPin[totalUsers]  = hashPin(pin);
  userMeanGap[totalUsers] = 0;
  userStdGap[totalUsers]  = 100;
  userSamples[totalUsers] = 0;
  totalUsers++;
  saveUsers();
  saveProfiles();
  logEvent(ACCESS_FILE, "ADMIN,ADD_USER,flat=" + flat);
  return true;
}

bool changeUserPin(const String& flat, const String& newPin) {
  int i = findByFlat(flat);
  if (i < 0) return false;
  if (pinTaken(newPin, i)) return false;
  userPin[i] = hashPin(newPin);
  userMeanGap[i] = 0;                     // new PIN = new rhythm, learn again
  userStdGap[i]  = 100;
  userSamples[i] = 0;
  saveUsers();
  saveProfiles();
  logEvent(ACCESS_FILE, "ADMIN,CHANGE_PIN,flat=" + flat);
  return true;
}

bool deleteUser(const String& flat) {
  int i = findByFlat(flat);
  if (i < 0) return false;
  for (int j = i; j < totalUsers - 1; j++) {
    userFlat[j] = userFlat[j + 1];
    userName[j] = userName[j + 1];
    userPin[j]  = userPin[j + 1];
    userMeanGap[j] = userMeanGap[j + 1];
    userStdGap[j]  = userStdGap[j + 1];
    userSamples[j] = userSamples[j + 1];
  }
  totalUsers--;
  saveUsers();
  saveProfiles();
  logEvent(ACCESS_FILE, "ADMIN,DELETE_USER,flat=" + flat);
  return true;
}

// ===================================================================
//  AI online learning (running average of typing rhythm)
// ===================================================================
void learnTyping(int idx) {
  if (gapCount < PIN_LENGTH - 1) return;
  float avgGap = (float)gapSum / gapCount;
  if (avgGap > 3000) return;              // typed with a long pause: ignore
  if (userSamples[idx] == 0) {
    userMeanGap[idx] = avgGap;
    userStdGap[idx]  = 100;
  } else {
    const float alpha = 0.2;              // learning rate
    float dev = fabs(avgGap - userMeanGap[idx]);
    userMeanGap[idx] += alpha * (avgGap - userMeanGap[idx]);
    userStdGap[idx]  += alpha * (dev - userStdGap[idx]);
  }
  userSamples[idx]++;
  Serial.println("AI learned rhythm for flat " + userFlat[idx] +
                 ": mean=" + String(userMeanGap[idx], 0) + "ms, samples=" +
                 String(userSamples[idx]));
  saveProfiles();
}

// ===================================================================
//  Displays
// ===================================================================
void showIdleScreen() {
  lcd.clear();
  lcd.print("Enter PIN:");
  lcd.setCursor(0, 1);
}

void panelIdle() {
  panel.clear();
  panel.setCursor(0, 0); panel.print("== NOTICE  BOARD ==");
  panel.setCursor(0, 1); panel.print(pad20("Flats:" + String(totalUsers) + " Alerts:" + String(alertCount)));
  panel.setCursor(0, 2); panel.print(pad20("In:" + String(grantedCount) + " Denied:" + String(deniedCount)));
  panel.setCursor(0, 3); panel.print(pad20("Last: " + lastEvent));
}

void panelMessage(String l0, String l1, String l2, String l3) {
  panel.clear();
  panel.setCursor(0, 0); panel.print(pad20(l0));
  panel.setCursor(0, 1); panel.print(pad20(l1));
  panel.setCursor(0, 2); panel.print(pad20(l2));
  panel.setCursor(0, 3); panel.print(pad20(l3));
}

// ===================================================================
//  Alerts, success, failure
// ===================================================================
void alertDenied() {
  for (int i = 0; i < 2; i++) {
    tone(BUZZER_PIN, 1500); delay(120);
    noTone(BUZZER_PIN);     delay(120);
  }
}

void sendSms(int idx, const String& msg) {   // simulated SMS
  Serial.println("SMS -> Flat " + userFlat[idx] + " (" + userName[idx] + "): " + msg);
}

// Collective security: message goes to EVERY resident.
void triggerSecurityAlert(const String& reason) {
  alertCount++;
  lastEvent = reason;
  logEvent(ALERT_FILE, "ALERT," + reason + ",notified=" + String(totalUsers));

  String msg = "SECURITY ALERT at main door: " + reason + ". All residents stay alert!";
  for (int i = 0; i < totalUsers; i++) sendSms(i, msg);

  panelMessage("!! SECURITY ALERT !!",
               reason,
               "Alerting " + String(totalUsers) + " flats",
               "ALL FLATS BE ALERT");

  lcd.clear();
  lcd.print("ALERT SENT TO");
  lcd.setCursor(0, 1);
  lcd.print("ALL RESIDENTS");

  lockDoorNow();                          // fail secure
  startSiren();
}

// Silent duress alarm: no siren, no display change, door still opens
void silentDuressAlert(int idx) {
  logEvent(ALERT_FILE, "DURESS,silent,flat=" + userFlat[idx]);
  for (int i = 0; i < totalUsers; i++) {
    if (i == idx) continue;
    sendSms(i, "SILENT DURESS ALARM: flat " + userFlat[idx] + " is being forced at the main door. Call the police.");
  }
}

void registerFailure(const String& method, const String& detail) {
  failedAttempts++;
  deniedCount++;
  logEvent(ACCESS_FILE, "DENIED," + method + "," + detail +
                        ",attempt=" + String(failedAttempts));

  lcd.clear();
  lcd.print(method + " FAILED");
  lcd.setCursor(0, 1);
  lcd.print("Attempt " + String(failedAttempts) + "/" + String(MAX_ATTEMPTS));
  alertDenied();

  if (failedAttempts >= MAX_ATTEMPTS) {
    triggerSecurityAlert(String(MAX_ATTEMPTS) + " WRONG ATTEMPTS");
    unsigned long lockMs = LOCKOUT_MS;    // escalating lockout
    for (int i = 0; i < lockoutLevel && i < MAX_LOCK_LEVEL; i++) lockMs *= 2;
    lockoutLevel++;
    lockedUntil = millis() + lockMs;
    logEvent(ACCESS_FILE, "LOCKOUT,seconds=" + String(lockMs / 1000));
    failedAttempts = 0;
    lastCountdown = 0;
    screenResetAt = 0;
  } else {
    panelMessage("Warning:", "Failed attempt " + String(failedAttempts),
                 "at main door", "");
    screenResetAt = millis() + 1500;
  }
}

void grantAccess(const String& who, const String& method) {
  failedAttempts = 0;
  lockoutLevel = 0;
  grantedCount++;
  logEvent(ACCESS_FILE, "GRANTED," + method + "," + who);
  lastEvent = who + " in";

  lcd.clear();
  lcd.print("Access Granted");
  lcd.setCursor(0, 1);
  lcd.print(who);
  panelMessage("Door opened by:", who, "", "");
  openDoor();
  screenResetAt = millis() + 2500;
}

// ===================================================================
//  Keypad entry
// ===================================================================
String readKeypadEntry(int length) {      // '*' cancels, timeout returns ""
  String entry = "";
  unsigned long start = millis();
  while (entry.length() < (unsigned)length) {
    backgroundTasks();
    if (millis() - start > ENTRY_TIMEOUT_MS) return "";
    char k = keypad.getKey();
    if (!k) continue;
    if (k == '*') return "";
    if (k >= '0' && k <= '9') {
      entry += k;
      tone(BUZZER_PIN, 2000, 30);
      lcd.setCursor(entry.length() - 1, 1);
      lcd.print(SHOW_ENTERED_DIGITS ? k : '*');
      start = millis();
    }
  }
  waitMs(300);
  return entry;
}

char waitMenuKey(unsigned long timeoutMs) {   // returns A-D, or 0 on timeout
  unsigned long start = millis();
  while (millis() - start < timeoutMs) {
    backgroundTasks();
    char k = keypad.getKey();
    if (k == 'A' || k == 'B' || k == 'C' || k == 'D') return k;
  }
  return 0;
}

// ---------- Admin actions ----------
void adminAdd() {
  lcd.clear(); lcd.print("Flat no (3 dig):");
  String flat = readKeypadEntry(FLAT_LENGTH);
  if (flat == "") return;
  lcd.clear(); lcd.print("New PIN:");
  String pin = readKeypadEntry(PIN_LENGTH);
  lcd.clear();
  lcd.print((pin != "" && addUser(flat, pin)) ? "User Added!" : "Add Failed");
  waitMs(1500);
}

void adminChange() {
  lcd.clear(); lcd.print("Flat no (3 dig):");
  String flat = readKeypadEntry(FLAT_LENGTH);
  if (flat == "") return;
  lcd.clear(); lcd.print("New PIN:");
  String pin = readKeypadEntry(PIN_LENGTH);
  lcd.clear();
  lcd.print((pin != "" && changeUserPin(flat, pin)) ? "PIN Changed!" : "Failed");
  waitMs(1500);
}

void adminDelete() {
  lcd.clear(); lcd.print("Delete flat no:");
  String flat = readKeypadEntry(FLAT_LENGTH);
  if (flat == "") return;
  lcd.clear();
  lcd.print(deleteUser(flat) ? "User Deleted!" : "Not Found");
  waitMs(1500);
}

String makeGuestPin() {
  randomSeed(analogRead(A15) ^ micros());
  for (int tries = 0; tries < 20; tries++) {
    String p = String((long)random(1000, 10000));
    if (!pinTaken(p, -1)) return p;
  }
  return "";
}

void adminGuest() {
  lcd.clear(); lcd.print("Guest for flat:");
  String flat = readKeypadEntry(FLAT_LENGTH);
  if (flat == "") return;
  if (findByFlat(flat) < 0) {
    lcd.clear(); lcd.print("Flat not found");
    waitMs(1500);
    return;
  }
  String p = makeGuestPin();
  if (p == "") { lcd.clear(); lcd.print("Try again"); waitMs(1500); return; }
  guestPin = p;
  guestFlat = flat;
  guestExpires = millis() + GUEST_VALID_MS;
  logEvent(ACCESS_FILE, "ADMIN,GUEST_PIN,flat=" + flat);
  Serial.println("SMS -> Flat " + flat + ": guest code " + p + " (valid 5 min, one use)");
  lcd.clear();
  lcd.print("Guest PIN: " + p);
  lcd.setCursor(0, 1);
  lcd.print("Valid 5 min x1");
  waitMs(8000);
}

void adminListUsers() {
  Serial.println("----- RESIDENTS -----");
  for (int i = 0; i < totalUsers; i++) {
    Serial.println("Flat " + userFlat[i] + "  " + userName[i] +
                   "  AI samples=" + String(userSamples[i]));
  }
  Serial.println("----- end -----");
  lcd.clear();
  lcd.print("Users: " + String(totalUsers));
  lcd.setCursor(0, 1);
  lcd.print("See Serial Mon.");
  waitMs(2000);
}

void clearLogs() {
  if (sdReady) { SD.remove(ACCESS_FILE); SD.remove(ALERT_FILE); }
  logEvent(ACCESS_FILE, "ADMIN,CLEAR_LOGS");
}

void adminClearLogs() {
  lcd.clear(); lcd.print("Clear all logs?");
  lcd.setCursor(0, 1); lcd.print("A:Yes  D:No");
  char c = waitMenuKey(10000UL);
  lcd.clear();
  if (c == 'A') { clearLogs(); lcd.print("Logs cleared"); }
  else          { lcd.print("Cancelled"); }
  waitMs(1200);
}

void showAdminMenu() {
  int page = 1;
  while (true) {
    lcd.clear();
    if (page == 1) {
      lcd.print("A:Add B:ChgPIN");
      lcd.setCursor(0, 1);
      lcd.print("C:Del  D:More");
    } else {
      lcd.print("A:Guest B:Users");
      lcd.setCursor(0, 1);
      lcd.print("C:ClrLog D:Exit");
    }
    char c = waitMenuKey(20000UL);
    if (c == 0) break;                    // timeout
    if (page == 1) {
      if      (c == 'A') adminAdd();
      else if (c == 'B') adminChange();
      else if (c == 'C') adminDelete();
      else if (c == 'D') page = 2;
    } else {
      if      (c == 'A') adminGuest();
      else if (c == 'B') adminListUsers();
      else if (c == 'C') adminClearLogs();
      else if (c == 'D') break;
    }
  }
  panelIdle();
  showIdleScreen();
}

// ===================================================================
//  Main input handlers
// ===================================================================
void expireGuestIfNeeded() {
  if (guestPin.length() && millis() > guestExpires) {
    logEvent(ACCESS_FILE, "GUEST,expired,flat=" + guestFlat);
    guestPin = "";
  }
}

void handleKeypad() {
  char key = keypad.getKey();
  if (!key) return;

  if (screenResetAt) {                    // leave the result screen on first key
    screenResetAt = 0;
    panelIdle();
    showIdleScreen();
  }

  // Super admin entry
  if (key == 'A' && enteredPIN == "") {
    lcd.clear();
    lcd.print("Enter SuperPIN:");
    String superEntry = readKeypadEntry(PIN_LENGTH);
    if (superEntry == "") {               // cancelled or timed out
      showIdleScreen();
    } else if (superEntry == SUPER_ADMIN_PIN) {
      logEvent(ACCESS_FILE, "ADMIN,LOGIN,ok");
      showAdminMenu();
    } else {
      registerFailure("SUPER PIN", "wrong admin pin");
    }
    return;
  }

  if (key == '#') {
    if (enteredPIN.length() == 0) return;
    String tried = enteredPIN;
    enteredPIN = "";
    expireGuestIfNeeded();

    if (guestPin.length() && tried == guestPin) {
      // ---- one-time guest PIN ----
      String f = guestFlat;
      guestPin = "";                      // single use
      int gi = findByFlat(f);
      if (gi >= 0) sendSms(gi, "Your guest has just entered.");
      grantAccess("Guest of " + f, "GUEST PIN");
    } else {
      int idx = findByPin(tried);
      if (idx >= 0) {
        // ---- correct PIN: ask the AI engine how risky it looks ----
        float risk = riskScore(idx);
        Serial.println("AI risk score: " + String(risk, 2));
        logEvent(ACCESS_FILE, "AI,risk=" + String(risk, 2) + ",flat=" + userFlat[idx]);
        if (risk >= RISK_THRESHOLD) {
          registerFailure("AI RISK", "score=" + String(risk, 2));
        } else {
          learnTyping(idx);
          grantAccess("Flat " + userFlat[idx], "PIN");
        }
      } else {
        // ---- duress PIN? (real PIN with last digit +1) ----
        int d = (tried.length() == PIN_LENGTH) ? findByPin(shiftLast(tried, -1)) : -1;
        if (d >= 0) {
          silentDuressAlert(d);
          grantAccess("Flat " + userFlat[d], "PIN");   // looks normal on screen
        } else {
          registerFailure("PIN", "wrong pin");        // attempted PIN is NOT logged
        }
      }
    }
    resetTyping();
  }
  else if (key == '*') {
    enteredPIN = "";
    resetTyping();
    showIdleScreen();
  }
  else if (key >= '0' && key <= '9') {
    if (enteredPIN.length() < PIN_LENGTH) {
      unsigned long now = millis();
      if (enteredPIN.length() > 0) { gapSum += now - lastKeyTime; gapCount++; }
      lastKeyTime = now;
      enteredPIN += key;
      tone(BUZZER_PIN, 2000, 30);
      lcd.setCursor(enteredPIN.length() - 1, 1);
      lcd.print(SHOW_ENTERED_DIGITS ? key : '*');
    }
  }
}

void handleIdleTimeout() {
  if (enteredPIN.length() > 0 && millis() - lastKeyTime > IDLE_CLEAR_MS) {
    enteredPIN = "";
    resetTyping();
    showIdleScreen();
  }
}

void handleScreenReset() {
  if (screenResetAt != 0 && millis() >= screenResetAt) {
    screenResetAt = 0;
    panelIdle();
    showIdleScreen();
  }
}

void handleFingerprint() {
  bool m = (digitalRead(FP_MATCH_PIN) == LOW);
  if (m && !fpMatchWas) {
    delay(30);
    if (digitalRead(FP_MATCH_PIN) == LOW) grantAccess("Fingerprint user", "FINGERPRINT");
  }
  fpMatchWas = m;

  bool n = (digitalRead(FP_NOMATCH_PIN) == LOW);
  if (n && !fpNoMatchWas) {
    delay(30);
    if (digitalRead(FP_NOMATCH_PIN) == LOW) registerFailure("FINGERPRINT", "no match");
  }
  fpNoMatchWas = n;
}

void handleTamper() {
  if (digitalRead(TAMPER_PIN) == LOW &&
      (lastTamper == 0 || millis() - lastTamper > TAMPER_COOLDOWN)) {
    delay(50);
    if (digitalRead(TAMPER_PIN) == LOW) {
      lastTamper = millis();
      logEvent(ACCESS_FILE, "TAMPER,force detected on lock");
      triggerSecurityAlert("DOOR TAMPERING!");
      lockedUntil = millis() + LOCKOUT_MS;
      lastCountdown = 0;
      screenResetAt = 0;
    }
  }
}

// ===================================================================
//  Serial commands
// ===================================================================
void printStatus() {
  Serial.println("----- STATUS -----");
  Serial.println("Uptime       : " + timestamp());
  Serial.println("Residents    : " + String(totalUsers));
  Serial.println("Granted      : " + String(grantedCount));
  Serial.println("Denied       : " + String(deniedCount));
  Serial.println("Alerts       : " + String(alertCount));
  Serial.println("Lockout level: " + String(lockoutLevel));
  Serial.println("Guest PIN    : " + String(guestPin.length() ? "active" : "none"));
  Serial.println("SD card      : " + String(sdReady ? "ok" : "missing"));
  Serial.println("------------------");
}

void printHelp() {
  Serial.println("Commands: l=access log  a=alert log  u=users file");
  Serial.println("          p=AI profiles s=status      c=clear logs  h=help");
}

void handleSerialCommands() {
  if (!Serial.available()) return;
  char c = Serial.read();
  if      (c == 'l') printFile(ACCESS_FILE);
  else if (c == 'a') printFile(ALERT_FILE);
  else if (c == 'u') printFile(USERS_FILE);
  else if (c == 'p') printFile(PROFILE_FILE);
  else if (c == 's') printStatus();
  else if (c == 'c') { clearLogs(); Serial.println("Logs cleared"); }
  else if (c == 'h') printHelp();
}

// ===================================================================
//  Setup / Loop
// ===================================================================
void setup() {
  Serial.begin(9600);

  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(LED_PIN, OUTPUT);
  pinMode(ALERT_LED_PIN, OUTPUT);
  pinMode(FP_MATCH_PIN, INPUT_PULLUP);
  pinMode(FP_NOMATCH_PIN, INPUT_PULLUP);
  pinMode(TAMPER_PIN, INPUT_PULLUP);

  doorLock.attach(SERVO_PIN);
  doorLock.write(LOCK_ANGLE);

  lcd.init();   lcd.backlight();
  panel.init(); panel.backlight();

  lcd.print("Starting...");
  sdReady = SD.begin(SD_CS);
  lcd.clear();
  lcd.print(sdReady ? "SD Card OK" : "SD FAILED!");
  Serial.println(sdReady ? "SD card ready" : "SD card init failed - running without logs");
  delay(1000);

  for (int i = 0; i < MAX_USERS; i++) {   // AI starts with nothing learned
    userMeanGap[i] = 0;
    userStdGap[i]  = 100;
    userSamples[i] = 0;
  }
  loadUsers();
  loadProfiles();                         // restore what the AI learned before
  logEvent(ACCESS_FILE, "SYSTEM,BOOT,users=" + String(totalUsers));

  panelIdle();
  showIdleScreen();
  Serial.println("Smart Lock v2 ready. AI learns after 3 good entries.");
  printHelp();
}

void loop() {
  backgroundTasks();
  handleSerialCommands();
  handleTamper();

  // ---- Locked out after repeated failures / tampering ----
  if (millis() < lockedUntil) {
    keypad.getKey();                      // discard key presses
    if (!sirenActive() && millis() - lastCountdown >= 1000) {
      lastCountdown = millis();
      unsigned long left = (lockedUntil - millis()) / 1000 + 1;
      lcd.clear();
      lcd.print("SYSTEM LOCKED");
      lcd.setCursor(0, 1);
      lcd.print("Wait " + String(left) + "s");
      panelMessage("!! LOCKDOWN ACTIVE !!", "Main door locked", "for security",
                   "Retry in " + String(left) + "s");
    }
    return;
  }
  if (lockedUntil != 0) {                 // lockout just ended
    lockedUntil = 0;
    panelIdle();
    showIdleScreen();
  }

  handleKeypad();
  handleFingerprint();
  handleIdleTimeout();
  handleScreenReset();
}
